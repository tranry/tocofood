import 'package:totofood/pages/CheckboxView.dart';
import 'package:totofood/pages/FrostedGlassBox.dart';
import 'package:totofood/pages/IconBox.dart';
import 'package:totofood/widgets/AppColor.dart';
import 'package:totofood/widgets/app_text.dart';
import 'package:flutter/material.dart';

class WellComeBack extends StatelessWidget {
   WellComeBack({Key? key});
  List image=[
    "fbicon.png",
    "google.png"
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
        children: [
          Padding(
            padding: EdgeInsets.only(top: 10),
            child: Image.asset('assets/images/logoGtech.png',width: 120,),

          ),
          const SizedBox(
            height: 50
          )
          ,Container(
            margin: EdgeInsets.only(left: 15),
            child: AppText(text: "CHÀO MỪNG BẠN ĐẾN VỚI GTECH",size: 25,weight: FontWeight.bold,col: AppColor.whiteLow,textAlign: TextAlign.center),
          width: 250,

          ),
          const SizedBox(
              height: 80
          ),
          FrostedGlassBox(child: AppText(text: "Đăng Nhập",col: AppColor.whiteHigh,size: 16), height: 50, width: 250),
          const SizedBox(
              height: 40
          ),
          FrostedGlassBox(child: AppText(text: "Đăng Ký",col: Colors.black,size: 16,), height: 50, width: 250,opacityleft: 0.9,opacityright: 0.9,),
          const SizedBox(
              height: 30
          ),SocialMediaView()
        ],
      );
  }
  Widget SocialMediaView()
  {
    return Container(
      margin: const EdgeInsets.only(top: 70,bottom: 30,left: 15),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CheckboxView(),
              AppText(text: "Tôi đồng ý với Điều Khoản và Điều Kiện",col: Colors.white,),
            ],
          ),

          AppText(text: "& Chính sách quyền riêng tư.",col: Colors.white,)
        ],
      )

    );
  }
}
