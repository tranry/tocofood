import 'package:flutter/material.dart';

class Product {
  final int id;
  final String title, description;
  final List<String> images;
  final List<Color> colors;
  final double rating, price;
  final bool isFavourite, isPopular;

  Product({
    required this.id,
    required this.images,
    required this.colors,
    this.rating = 0.0,
    this.isFavourite = false,
    this.isPopular = false,
    required this.title,
    required this.price,
    required this.description,
  });
}

// Our demo Products

List<Product> demoProducts = [
  Product(
    id: 1,
    images: [
      "assets/images/nuocephoaqua.jpg",
      "assets/images/tracam.jpg",
      "assets/images/nuocdua.jpg",
      "assets/images/travai.jpg",
    ],
    colors: [
      Color(0xFFF6625E),
      Color(0xFF836DB8),
      Color(0xFFDECB9C),
      Colors.white,
    ],
    title: "Nước Ép Hoa Quả",
    price: 30000,
    description: description[0],
    rating: 4.8,
    isFavourite: true,
    isPopular: true,
  ),
  Product(
    id: 2,
    images: [
      "assets/images/banhgaocay.jpg",
    ],
    colors: [
      Color(0xFFF6625E),
      Color(0xFF836DB8),
      Color(0xFFDECB9C),
      Colors.white,
    ],
    title: "Bánh gạo tokbokki",
    price: 50000,
    description: description[1],
    rating: 4.1,
    isPopular: true,
  ),
  Product(
    id: 3,
    images: [
      "assets/images/mixao.jpg",
    ],
    colors: [
      Color(0xFFF6625E),
      Color(0xFF836DB8),
      Color(0xFFDECB9C),
      Colors.white,
    ],
    title: "Mì Udon Xào Kim Chi ",
    price: 64564,
    description: description[2],
    rating: 4.1,
    isFavourite: true,
    isPopular: true,
  ),
  Product(
    id: 4,
    images: [
      "assets/images/comcuon.jpg",
    ],
    colors: [
      Color(0xFFF6625E),
      Color(0xFF836DB8),
      Color(0xFFDECB9C),
      Colors.white,
    ],
    title: "Rong Biển Cuộn Cơm",
    price: 20000,
    description: description[3],
    rating: 4.1,
    isFavourite: true,
    isPopular: true,
  ),
];

const List<String> description =[
  "Trà trái cây - với nguyên liệu chính là những là trà khô, kết hợp cùng với những loại trái cây nhiệt đới khác nhau (đào, xoài, dứa, vải, chanh…) để tạo thành loại trà có hương và vị trái cây thanh mát, dễ uống và giải nhiệt tốt.",
  "Thưởng thức Tokbokki / Tokpokki O’Food ăn liền chuẩn vị Hàn Quốc thật đơn giản và tiện lợi chỉ cần nước sôi, ăn liền sau 3 phút. Bánh gạo mềm, dẻo, thơm ngon. Sốt sánh, mịn, chuẩn vị tokpokki với 5 vị siêu hot.",
  "Mì Udon Hàn Quốc thường có một mì dày, mềm và tròn, được làm từ bột mỳ và nước. Những sợi mì này có độ dai vừa phải, tạo cảm giác ngon miệng khi nhấp nhất. Mì Udon thường được chế biến thành các món ăn khác nhau, từ mì hấp đơn giản đến các biến thể phong phú hơn.",
  "Tảo biển Yaki Sushi Nori được làm từ 100% tảo biển sấy khô từ Hàn Quốc, đây sẽ là nguyên liệu giúp bạn chế biến những món ăn thơm ngon, bổ dưỡng.Sản phẩm chứa nhiều khoáng chất, các yếu tố vi lượng và vitamin rất tốt cho sức khỏe.Có thể ăn liền hoặc ăn với cơm trắng, cuộn kimbap, .Vị dễ ăn nên thích hợp cho cả trẻ em và người lớn."
];
