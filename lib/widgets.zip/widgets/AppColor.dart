
import 'dart:ui';

class AppColor {
  static final Color whiteHigh = Color(0xffF1F1F1);
  static final Color whiteLow = Color(0xffF3F3F3);
  static final Color white = Color(0xffDFDFDF);
  static final Color green = Color(0xffDDEAD7);
}