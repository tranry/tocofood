import 'package:totofood/components/coustom_bottom_nav_bar.dart';
import 'package:totofood/enums.dart';
import 'package:totofood/screens/favourite/components/body.dart';
import 'package:flutter/material.dart';

class MessageScreen extends StatelessWidget {
  static String routeName = "/message";
    @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.message),
    );
  }
}

