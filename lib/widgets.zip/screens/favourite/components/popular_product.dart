import 'package:totofood/components/product_card.dart';
import 'package:totofood/models/Product.dart';
import 'package:totofood/screens/home/components/section_title.dart';
import 'package:totofood/size_config.dart';
import 'package:flutter/material.dart';

class PopularProducts extends StatefulWidget {
  @override
  _PopularProductsState createState() => _PopularProductsState();
}

class _PopularProductsState extends State<PopularProducts> {
  List<Product> products = demoProducts; // Assume initial products list

  void onBuyButtonPressed(Product product) {
    setState(() {
      products.remove(product); // Remove the product from the list
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 15),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: getProportionateScreenWidth(30)),
            child: SectionTitle(title: "Sản Phẩm Yêu Thích", press: () {}, all: 0),
          ),
          SizedBox(height: getProportionateScreenWidth(10)),
          GridView.count(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            mainAxisSpacing: 2,
            childAspectRatio: 0.66,
            children: products.map((product) {
              if (product.isPopular) {
                return Column(
                  children: [
                    ProductCard(
                      hideButton: 0,
                      formKey: GlobalKey<FormState>(),
                      text: "Mua Ngay",
                      product: product,
                      press: () => onBuyButtonPressed(product), // Pass the buy callback
                    ),
                  ],
                );
              } else {
                return SizedBox.shrink();
              }
            }).toList(),
          ),
        ],
      ),
    );
  }
}