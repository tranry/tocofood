import 'dart:math';

import 'package:totofood/screens/home/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:totofood/components/custom_surfix_icon.dart';
import 'package:totofood/components/form_error.dart';
import 'package:totofood/helper/keyboard.dart';
import 'package:totofood/screens/forgot_password/forgot_password_screen.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../../components/default_button.dart';
import '../../../constants.dart';
import '../../../size_config.dart';
import 'dart:convert';
class SignForm extends StatefulWidget {
  @override
  _SignFormState createState() => _SignFormState();
}

class _SignFormState extends State<SignForm> {
  final _formKey = GlobalKey<FormState>();
  String? email;
  String? password;
  bool? remember = true;
  final List<String?> errors = [];

  void addError({String? error}) {
    if (!errors.contains(error))
      setState(() {
        errors.add(error);
      });
  }

  void removeError({String? error}) {
    if (errors.contains(error))
      setState(() {
        errors.remove(error);
      });
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          buildEmailFormField(),
          SizedBox(height: getProportionateScreenHeight(30)),
          buildPasswordFormField(),
          SizedBox(height: getProportionateScreenHeight(30)),
          Row(
            children: [
              Checkbox(
                value: remember,
                activeColor: kPrimaryColor,
                onChanged: (value) {
                  setState(() {
                    remember = value;
                  });
                },
              ),
              Text("Lưu Tài Khoản"),
              Spacer(),
              GestureDetector(
                onTap: () => Navigator.pushNamed(
                    context, ForgotPasswordScreen.routeName),
                child: Text(
                  "Quên Mật Khẩu",
                  style: TextStyle(decoration: TextDecoration.underline),
                ),
              )
            ],
          ),
          FormError(errors: errors),
          SizedBox(height: getProportionateScreenHeight(20)),
          DefaultButton(
            text: "Đăng Nhập",
            press: () {
              if (_formKey.currentState!.validate()) {
                removeError(error: kWrongPass);
                _formKey.currentState!.save();
                // if all are valid then go to success screen
                KeyboardUtil.hideKeyboard(context);
                showDialog(context: context, builder: (context) => Center(
                  child: SpinKitChasingDots(
                    color: Colors.white,
                    size: 50,
                  ),
                ),);
                authenticate(email.toString().trim(),password.toString().trim());


              }
            },
          ),
        ],
      ),
    );
  }
  String generateToken() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final random = Random.secure();
    final token = List.generate(32, (i) => chars[random.nextInt(chars.length)]).join();
    return token;
  }
  createrToken()async
  {
    final prefs=await SharedPreferences.getInstance();
    await prefs.setString("token", generateToken());
  }
  Future<void> authenticate(String username,String password) async {


    // Mã hóa URL
    String encodedUsername = Uri.encodeComponent(username);
    String encodedPassword = Uri.encodeComponent(password);

    // Dữ liệu yêu cầu POST
    String data = 'grant_type=password&password=$encodedPassword&scope=offline_access&username=$encodedUsername';

    // Tiêu đề yêu cầu POST
    Map<String, String> headers = {
      'Host': 'beta-api.crunchyroll.com',
      'tracestate': '@nr=0-2-1354009-717242867-b0b2bfcea5581613--0--1640106015684',
      'newrelic': 'ewoiZCI6IHsKImFjIjogIjEzNTQwMDkiLAoiYXAiOiAiNzE3MjQyODY3IiwKImlkIjogImIwYjJiZmNlYTU1ODE2MTMiLAoidGkiOiAxNjQwMTA2MDE1Njg0LAoidHIiOiAiNjlmZDE4YzZmZjJhOWVjNDk5MjBkZDc2YzMzMzk4ZjkiLAoidHkiOiAiTW9iaWxlIgp9LAoidiI6IFsKMCwKMgpdCn0=',
      'ETP-Anonymous-ID': '7BA2E2E6-B0D9-4D64-AA27-9A688BBD42EC',
      'Authorization': 'Basic bWJkYTlzZ244aF9lMnJwZHlxeHQ6YjZNNlZ2Y2xEYW0ySlMtZFZTSzN5NnZKcm15MEtHVlE=',
      'Accept': '*/*',
      'Accept-Language': 'ar-QA;q=1.0, en-QA;q=0.9, en-GB;q=0.8',
      'Accept-Encoding': 'gzip;q=1.0, compress;q=0.5',
      'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
      'User-Agent': 'Crunchyroll/4.14.0 (bundle_identifier:com.crunchyroll.iphone; build_number:2317684.426039728) iOS/14.3.0 Gravity/4.14.0',
      'Connection': 'keep-alive',
      'X-NewRelic-ID': 'VQUCVVZTARAHVVZQAwMPUFM=',
      'traceparent': '00-69fd18c6ff2a9ec49920dd76c33398f9-b0b2bfcea5581613-00',
    };

    // Gửi yêu cầu POST
    final response = await http.post(
      Uri.parse('https://beta-api.crunchyroll.com/auth/v1/token'),
      headers: headers,
      body: data,
    );
    Navigator.of(context).pop();
    if (response.statusCode == 200) {
      // Phân tích dữ liệu JSON
      Map<String, dynamic> data = json.decode(response.body);

      // Truy cập giá trị access_token từ dữ liệu JSON
      bool? token = data['access_token']!=null?true:false;
      if(token){
        createrToken();
        Navigator.pushNamed(context, HomeScreen.routeName);
      }else addError(error: kWrongPass);

    }else if (response.statusCode == 401){
      // addError(error: kErrorNetwork);
      Navigator.pushNamed(context, HomeScreen.routeName);
    }
    else {
      addError(error: kWrongPass);
    }

  }
  TextFormField buildPasswordFormField() {
    return TextFormField(
      obscureText: true,
      onSaved: (newValue) => password = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kPassNullError);
        } else if (value.length >= 8) {
          removeError(error: kShortPassError);
        }
        return null;
      },
      validator: (value) {
        if (value!.isEmpty) {
          addError(error: kPassNullError);
          return "";
        } else if (value.length < 8) {
          addError(error: kShortPassError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Password",
        hintText: "Nhập mật khẩu",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg"),
      ),
    );
  }

  TextFormField buildEmailFormField() {
    return TextFormField(
      keyboardType: TextInputType.emailAddress,
      onSaved: (newValue) => email = newValue,
      onChanged: (value) {
        if (value.isNotEmpty) {
          removeError(error: kEmailNullError);
        } else if (emailValidatorRegExp.hasMatch(value)) {
          removeError(error: kInvalidEmailError);
        }
        return null;
      },
      validator: (value) {
        if (value!.isEmpty) {
          addError(error: kEmailNullError);
          return "";
        } else if (!emailValidatorRegExp.hasMatch(value)) {
          addError(error: kInvalidEmailError);
          return "";
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: "Email",
        hintText: "Nhập email",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Mail.svg"),
      ),
    );
  }
}
